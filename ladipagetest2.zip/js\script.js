function submitOrder(e){
  e.preventDefault();
  alert('Cảm ơn bạn! Đơn hàng của bạn đã được ghi nhận.');
  return false;
}
