function scrollToId(id){ const el=document.getElementById(id); if(el){ el.scrollIntoView({behavior:'smooth'});} }
function buy(name){ alert('Đặt mua: '+name); }
console.log('[hopagetest1] script.js loaded');
