# Website Bán Thẻ Tập Huấn Nghiệp Vụ Vận Tải

## Mô tả
Website landing page bán thẻ tập huấn nghiệp vụ vận tải với phong cách tập trung vào nỗi sợ khách hàng về việc bị phạt nặng khi không có thẻ tập huấn.

## Đặc điểm nổi bật

### 1. Tâm lý Marketing Fear-Based
- **Cảnh báo khẩn cấp** về mức phạt 800.000đ - 12.000.000đ
- **Ảnh thực tế** công an kiểm tra xe để tạo sức ép tâm lý
- **Liệt kê chi tiết** các hậu quả nghiêm trọng
- **Tạo cảm giác khẩn cấp** với timer đếm ngược và thông báo số người bị phạt

### 2. Thiết kế Visual Impact
- **Ảnh thẻ thực tế** thay vì mockup để tăng độ tin cậy
- **Avatar thật** của khách hàng trong testimonials (kiểu Facebook)
- **Màu sắc cảnh báo**: Đỏ, cam để tạo cảm giác nguy hiểm
- **Animation**: Nhấp nháy, rung lắc để thu hút sự chú ý
- **Typography**: Font size lớn, in đậm cho các mức phạt
- **Icons**: Sử dụng biểu tượng cảnh báo, cấm, khiên bảo vệ

### 3. Tính năng Conversion
- **Multiple CTA**: Nút gọi điện, Zalo ở nhiều vị trí
- **Social Proof**: Testimonials và thông báo đặt hàng giả lập
- **Urgency Elements**: Đếm ngược thời gian, số lượng người bị phạt
- **Exit Intent Popup**: Giữ chân khách hàng định rời trang

### 4. UX/UI Tối ưu
- **Mobile Responsive**: Tối ưu cho điện thoại
- **Loading Speed**: CSS compact, images tối ưu
- **Floating Contact**: Nút liên hệ cố định
- **Smooth Scrolling**: Cuộn mượt mà giữa các section

## Cấu trúc Files

```
the-tap-huan-van-tai-3/
├── index.html          # File chính
├── css/
│   └── style.css      # Stylesheet chính
├── js/
│   └── script.js      # JavaScript tương tác
├── images/            # Thư mục chứa ảnh
│   ├── 476072043_*.jpg    # Avatar khách hàng 1
│   ├── 482022304_*.jpg    # Avatar khách hàng 2  
│   ├── 485872749_*.jpg    # Avatar khách hàng 3
│   ├── 500227651_*.jpg    # Avatar khách hàng 4
│   ├── 520259387_*.jpg    # Avatar khách hàng 5
│   ├── images (1).jpg     # Avatar khách hàng 6
│   ├── z7024682911357_*.jpg   # Ảnh thẻ mẫu
│   ├── z7078443468563_*.jpg   # Ảnh thẻ chính (hero)
│   ├── z7079448280472_*.jpg   # Ảnh thẻ mẫu phụ
│   ├── z7086049255540_*.jpg   # Ảnh CSGT kiểm tra xe
│   └── z7086154208379_*.jpg   # Ảnh thẻ mẫu phụ 2
└── README.md          # Hướng dẫn sử dụng
```

## Sections Website

1. **Header** - Logo và hotline nổi bật
2. **Warning Banner** - Cảnh báo khẩn cấp về phạt nặng
3. **Hero Section** - Tiêu đề chính + danh sách mức phạt + ảnh thẻ thật
4. **Penalty Details** - Ảnh CSGT kiểm tra xe + chi tiết các mức phạt
5. **Solution Section** - Lợi ích của việc làm thẻ
6. **Process** - 4 bước làm thẻ đơn giản
7. **Pricing** - 3 gói dịch vụ với giá ưu đãi
8. **Testimonials** - Đánh giá từ khách hàng với avatar thật (Facebook style)
9. **CTA Section** - Kêu gọi hành động cuối cùng
10. **Footer** - Thông tin liên hệ và cam kết

### Đặc điểm Testimonials mới:
- **Avatar thật** của 6 khách hàng khác nhau
- **Thiết kế Facebook-style** với header, avatar, verified badge
- **Thông tin chi tiết** về nghề nghiệp và địa điểm
- **Rating 5 sao** với text mô tả cảm xúc
- **Meta data** thời gian và số lượt thích
- **Thống kê tổng quan** điểm đánh giá và số khách hàng

## JavaScript Features

- **Smooth Scrolling** cho navigation
- **Intersection Observer** cho animations khi scroll
- **Counter tự động** số người bị phạt
- **Notification popup** giả lập đơn hàng mới
- **Exit Intent Popup** với ưu đãi đặc biệt
- **Progress Bar** hiển thị tiến độ đọc trang
- **Urgency Timer** đếm ngược thời gian ưu đãi
- **Click Tracking** cho analytics

## Tính năng Conversion

### Call-to-Action
- Nút "GỌI NGAY ĐỂ LÀM THẺ" ở hero section
- Nút "ĐẶT NGAY" cho từng gói dịch vụ
- Floating buttons cố định bên phải
- Exit intent popup với ưu đãi

### Social Proof
- Testimonials với rating 5 sao
- Popup thông báo đơn hàng mới (giả lập)
- Counter số người bị phạt hôm nay

### Urgency/Scarcity
- Timer đếm ngược ưu đãi
- Số lượng người bị phạt tăng theo thời gian thực
- Thông báo "Đừng để mất cơ hội"

## Technical Specs

### CSS Framework
- **CSS Variables** cho màu sắc thống nhất
- **CSS Grid & Flexbox** cho responsive layout
- **CSS Animations** cho hiệu ứng visual
- **Mobile-first** responsive design

### Browser Support
- Chrome, Firefox, Safari, Edge (modern browsers)
- Internet Explorer 11+ (limited support)
- Mobile browsers (iOS Safari, Chrome Mobile)

### Performance
- **CSS minified** theo format compact
- **Lazy loading** cho animations
- **Optimized images** (recommend WebP)
- **No external dependencies** ngoài Font Awesome

## Customization

### Thay đổi thông tin liên hệ
1. Sửa số điện thoại trong HTML: `0123.456.789`
2. Cập nhật link Zalo: `https://zalo.me/0123456789`
3. Thay đổi email trong footer

### Chỉnh sửa pricing
1. Mở file `index.html`
2. Tìm section `.pricing-section`
3. Cập nhật giá và features cho từng gói

### Thay đổi màu sắc
1. Mở file `css/style.css`
2. Chỉnh sửa CSS Variables trong `:root{}`
3. Các màu chính: `--danger-red`, `--warning-orange`, `--success-green`

### Thêm/Sửa testimonials
1. Tìm section `.testimonials` trong HTML
2. Thêm/sửa nội dung trong `.testimonial-item`

## Deployment

### Tạo file ZIP
```powershell
Compress-Archive -Path 'the-tap-huan-van-tai-3\*' -DestinationPath 'the-tap-huan-van-tai-3.zip' -Force
```

### Checklist trước upload
- ✅ Tất cả đường dẫn asset dùng `/css/`, `/js/`, `/images/`
- ✅ File `index.html` ở thư mục gốc
- ✅ CSS đã minified theo format compact
- ✅ Test responsive trên mobile
- ✅ Kiểm tra tất cả links hoạt động

## Marketing Strategy

### Target Audience
- Tài xế taxi, xe khách, container
- Chủ xe tải, xe vận chuyển hàng hóa
- Người cần gia hạn thẻ tập huấn
- Doanh nghiệp vận tải

### Key Messages
1. **Fear Factor**: Phạt nặng 800k-12 triệu nếu không có thẻ
2. **Solution**: Làm thẻ chỉ 299k so với mức phạt
3. **Urgency**: Làm nhanh trong 2-3 ngày
4. **Trust**: Thẻ chính thức, được CSGT công nhận

### Conversion Funnel
1. **Awareness**: Cảnh báo về mức phạt
2. **Interest**: Giải pháp làm thẻ giá rẻ
3. **Consideration**: So sánh 3 gói dịch vụ
4. **Action**: Gọi điện/Zalo đặt thẻ

## SEO Keywords
- thẻ tập huấn nghiệp vụ vận tải
- làm thẻ tập huấn vận tải
- phạt không có thẻ tập huấn
- thẻ nghiệp vụ lái xe
- gia hạn thẻ tập huấn
- mức phạt vi phạm giao thông
- thẻ tập huấn chính thức

## Analytics Tracking

Website có sẵn event tracking cho:
- Click buttons (CTA, pricing, contact)
- Phone call clicks
- Zalo message clicks
- Exit intent popup interactions
- Order attempt by package type

Tích hợp Google Analytics bằng cách thêm:
```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_TRACKING_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'GA_TRACKING_ID');
</script>
```

## Support

Để được hỗ trợ kỹ thuật hoặc tùy chỉnh thêm, liên hệ developer.

---

**Lưu ý**: Website được thiết kế theo phong cách fear-based marketing để tối đa hóa conversion rate. Sử dụng có trách nhiệm và đảm bảo tuân thủ pháp luật về quảng cáo.