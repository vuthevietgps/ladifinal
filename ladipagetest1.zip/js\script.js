function submitOrder(e){
  e.preventDefault();
  alert('Cảm ơn bạn! Chúng tôi sẽ liên hệ trong thời gian sớm nhất.');
  return false;
}
