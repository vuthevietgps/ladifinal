# Landing Page - Thẻ Tập Huấn Nghiệp Vụ Vận Tải

## 📋 Mô tả

Landing page theo công thức AIDA (Attention, Interest, Desire, Action) cho dịch vụ đăng ký thẻ tập huấn nghiệp vụ vận tải.

## 🎯 Cấu trúc AIDA

### 🔥 ATTENTION (Thu hút sự chú ý)
- Hero section với cảnh báo đỏ nổi bật
- Thông tin về mức phạt 3-5 triệu đồng
- Badges và animations để tạo sự cấp bách

### 😟 INTEREST (Khơi gợi sự quan tâm)
- Liệt kê các đối tượng BẮT BUỘC phải có thẻ
- Danh sách vấn đề người dùng đang gặp phải
- Risk warning box với thiết kế nổi bật

### 🎯 DESIRE (Kích thích mong muốn)
- Giải pháp 3 bước: Nhanh - Đúng - Hợp pháp
- Benefits grid với 4 lợi ích chính
- Social proof với hàng nghìn khách hàng thành công

### 🚀 ACTION (Kêu gọi hành động)
- CTA section với 2 nút chính: Đăng ký & Tư vấn
- Form đăng ký chi tiết
- Floating contact buttons (Phone & Zalo)
- Zalo popup tự động sau 10 giây

## 📁 Cấu trúc thư mục

```
the-tap-huan-van-tai-4/
├── index.html          # File HTML chính
├── css/
│   └── style.css      # Styles với design system hoàn chỉnh
├── js/
│   └── script.js      # JavaScript với đầy đủ tính năng
├── images/            # Thư mục hình ảnh
│   ├── gallery-1.jpg
│   ├── gallery-2.jpg
│   ├── gallery-3.jpg
│   └── gallery-4.jpg
└── README.md          # File này
```

## ✨ Tính năng

### 🎨 Design
- Modern & Clean UI
- Responsive design (mobile-first)
- Color scheme: Red (primary) + Blue (secondary)
- Smooth animations & transitions
- Custom icons với SVG

### 🚀 Chức năng
- ✅ Smooth scroll navigation
- ✅ Form validation
- ✅ Phone number formatting
- ✅ Zalo popup (auto-show sau 10s, lưu localStorage)
- ✅ Countdown timer (optional)
- ✅ Floating contact buttons
- ✅ Scroll animations
- ✅ Lazy loading images
- ✅ Click tracking ready
- ✅ Google Analytics & Facebook Pixel ready

### 📱 Contact Methods
- Hotline: 0363.614.511
- Zalo: 0363.614.511
- Form đăng ký trực tuyến

## 🔧 Tùy chỉnh

### Thay đổi số điện thoại
Tìm và thay thế `0363614511` trong:
- `index.html` (tất cả các thẻ `<a href="tel:">`)
- `index.html` (Zalo links: `https://zalo.me/84363614511`)

### Thay đổi màu sắc
Sửa CSS variables trong `css/style.css`:
```css
:root {
  --primary: #dc2626;        /* Màu chủ đạo */
  --secondary: #2563eb;      /* Màu phụ */
  --success: #16a34a;        /* Màu thành công */
}
```

### Thêm hình ảnh
Thay thế các file trong thư mục `images/`:
- `gallery-1.jpg` - Hình khách hàng nhận thẻ
- `gallery-2.jpg` - Hình lớp tập huấn
- `gallery-3.jpg` - Hình thẻ mẫu
- `gallery-4.jpg` - Hình giấy chứng nhận

### Kết nối API
Sửa hàm `initForm()` trong `js/script.js`:
```javascript
// TODO: Replace with your actual API endpoint
const response = await fetch('/api/leads', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify(data)
});
```

### Thêm Google Analytics
Thêm vào `<head>` trong `index.html`:
```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'GA_MEASUREMENT_ID');
</script>
```

### Thêm Facebook Pixel
Thêm vào `<head>` trong `index.html`:
```html
<!-- Facebook Pixel -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', 'YOUR_PIXEL_ID');
  fbq('track', 'PageView');
</script>
```

## 📊 Conversion Tracking

Landing page đã được tích hợp sẵn tracking cho:
- Phone calls
- Zalo clicks
- Form submissions
- CTA button clicks

Các events sẽ tự động gửi đến Google Analytics và Facebook Pixel khi được cài đặt.

## 🎯 Best Practices Implemented

- ✅ SEO-friendly HTML structure
- ✅ Semantic HTML5
- ✅ ARIA labels cho accessibility
- ✅ Meta tags đầy đủ
- ✅ Open Graph tags ready
- ✅ Mobile-first responsive
- ✅ Performance optimized
- ✅ Cross-browser compatible

## 📈 Conversion Rate Optimization (CRO)

Landing page được tối ưu cho conversion với:
- Multiple CTAs (Call-to-Action)
- Trust signals (badges, social proof)
- Urgency elements (countdown, limited slots)
- Clear value propositions
- Minimal friction form
- Mobile-optimized experience

## 🚀 Deployment

### Cách 1: Upload lên hosting
1. Upload toàn bộ thư mục lên web hosting
2. Đảm bảo file `index.html` ở root directory
3. Kiểm tra đường dẫn images và assets

### Cách 2: Tích hợp vào Flask app
1. Copy thư mục vào `ladifinal/published/`
2. Truy cập qua route `/landing/the-tap-huan-van-tai-4`

## 📞 Support

Nếu cần hỗ trợ kỹ thuật hoặc tùy chỉnh thêm, vui lòng liên hệ.

## 📝 Changelog

### Version 1.0 (2026-01-14)
- ✅ Initial release
- ✅ AIDA structure implementation
- ✅ Responsive design
- ✅ Full interactive features
- ✅ Form handling
- ✅ Analytics ready

---

**Created:** January 14, 2026  
**Framework:** Vanilla HTML/CSS/JS  
**Design Pattern:** AIDA  
**License:** Proprietary
