// Button click handlers and animations
document.addEventListener('DOMContentLoaded', function() {
    const ctaButtons = document.querySelectorAll('[id^="ctaButton"]');
    const floatingContacts = document.querySelectorAll('.contact-float');
    
    // Handle CTA button clicks
    ctaButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            // Create ripple effect
            createRipple(e, this);
            
            // Scroll to contact section or trigger action
            setTimeout(() => {
                const phoneNumber = '0363614511';
                const message = 'Tôi muốn nhận tư vấn miễn phí về đăng ký phù hiệu xe.';
                
                // Open Zalo by default (can be changed)
                window.open(`https://zalo.me/${phoneNumber}`, '_blank');
            }, 300);
        });
    });
    
    // Enhanced floating contact animations
    floatingContacts.forEach((contact, index) => {
        // Add pulsing glow effect
        contact.style.animationDelay = (index * 0.3) + 's';
        
        // Add click feedback
        contact.addEventListener('click', function(e) {
            e.preventDefault();
            createRipple(e, this);
        });
        
        // Hover animation
        contact.addEventListener('mouseenter', function() {
            this.style.animation = 'none';
            setTimeout(() => {
                this.style.animation = '';
            }, 10);
        });
    });
    
    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
    
    // Add scroll animations
    observeElements();
});

// Create ripple effect on button click
function createRipple(event, element) {
    const ripple = document.createElement('span');
    const rect = element.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    const x = event.clientX - rect.left - size / 2;
    const y = event.clientY - rect.top - size / 2;
    
    ripple.style.width = ripple.style.height = size + 'px';
    ripple.style.left = x + 'px';
    ripple.style.top = y + 'px';
    ripple.classList.add('ripple');
    
    // Remove existing ripples
    element.querySelectorAll('.ripple').forEach(r => r.remove());
    element.appendChild(ripple);
    
    // Remove ripple after animation
    setTimeout(() => ripple.remove(), 600);
}

// Observe elements for scroll animations
function observeElements() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });
    
    // Observe sections
    document.querySelectorAll('section').forEach(section => {
        section.style.opacity = '0';
        section.style.transform = 'translateY(20px)';
        section.style.transition = 'all 0.6s ease-out';
        observer.observe(section);
    });
}

// Add ripple style to page if not already present
if (!document.querySelector('style[data-ripple]')) {
    const style = document.createElement('style');
    style.setAttribute('data-ripple', 'true');
    style.textContent = `
        .btn, .contact-float {
            position: relative;
            overflow: hidden;
        }
        
        .ripple {
            position: absolute;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.5);
            transform: scale(0);
            animation: ripple-animation 0.6s ease-out;
            pointer-events: none;
        }
        
        @keyframes ripple-animation {
            to {
                transform: scale(4);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);
}

// Scroll to top button functionality (optional enhancement)
window.addEventListener('scroll', function() {
    const scrollY = window.scrollY;
    const floatingContacts = document.querySelector('.floating-contacts');
    
    if (floatingContacts) {
        // Add fade-in effect as user scrolls
        floatingContacts.style.opacity = Math.min(1, scrollY / 200);
    }
});

// Track button interactions for analytics (optional)
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('btn') || e.target.closest('.btn')) {
        const button = e.target.classList.contains('btn') ? e.target : e.target.closest('.btn');
        // Send analytics event
        if (window.gtag) {
            gtag('event', 'button_click', {
                'button_text': button.textContent.trim(),
                'button_id': button.id || 'unknown'
            });
        }
    }
});
